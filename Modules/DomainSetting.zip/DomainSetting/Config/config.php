<?php

return [
    'name' => 'DomainSetting'
];
