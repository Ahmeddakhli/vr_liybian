<?php

namespace Modules\DomainSetting\Http\Requests;

use App\Http\Requests\FormRequest;

class DeletedomainsRequest extends FormRequest
{
    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'id' => "required|exists:domains,id,deleted_at,NULL"
        ];
    }

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }
}
