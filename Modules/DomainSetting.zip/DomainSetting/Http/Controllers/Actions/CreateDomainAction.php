<?php

namespace Modules\DomainSetting\Http\Controllers\Actions;

use Modules\DomainSetting\Domain;
use DB;
use Carbon\Carbon;
use Modules\DomainSetting\Http\Resources\domainsResource;

class CreateDomainAction
{
    public function execute(array $data): domainsResource
    {
        $created_at = Carbon::now()->toDateTimeString();

        // Create domains
        $domains = Domain::create($data);

        // Reload the instance
        $domains = Domain::find($domains->id);

        // Transform the result
        $domains = new domainsResource($domains);

        return $domains;
    }
}
