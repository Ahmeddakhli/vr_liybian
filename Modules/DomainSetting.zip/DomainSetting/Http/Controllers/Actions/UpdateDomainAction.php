<?php

namespace Modules\DomainSetting\Http\Controllers\Actions;

use Modules\DomainSetting\Domain;
use Modules\DomainSetting\DomainTranslation;
use DB;
use Carbon\Carbon;

use Modules\DomainSetting\Http\Resources\domainsResource;

class UpdateDomainAction
{
    public function execute($id, array $data): domainsResource
    {
        $created_at = Carbon::now()->toDateTimeString();
        $updated_at = Carbon::now()->toDateTimeString();

        // Get the domains
        $domains = Domain::find($id);

        // Update the domains
        // Trigger update domains on domains to cache its values
        if (isset($data['show_short_description']) && $data['show_short_description'] == 'on') {
            $data['show_short_description'] = 1;
        } else {
            $data['show_short_description'] = 0;
        }
        $domains->update($data);

        $path = public_path('sitemap.xml');
        $sitemapContent = '<your updated sitemap content here>'; // Replace with the content you want to put in the sitemap

        // Check if the file exists
        // If the file exists, update its content
        file_put_contents($path, $sitemapContent);

        // Reload the instance
        $domains = Domain::find($domains->id);

        // Transform the result
        $domains = new domainsResource($domains);

        return $domains;
    }
}
