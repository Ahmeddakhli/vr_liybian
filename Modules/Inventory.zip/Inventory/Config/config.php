<?php

return [
    'name' => 'Inventory'
];
