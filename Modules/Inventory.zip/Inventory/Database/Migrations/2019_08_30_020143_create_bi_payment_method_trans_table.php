<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateBiPaymentMethodTransTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('i_payment_method_trans', function (Blueprint $table) {
            $table->integer('i_payment_method_id')->unsigned()->index();
            $table->foreign('i_payment_method_id')->references('id')->on('i_payment_methods');
            $table->integer('language_id')->unsigned()->index();
            //$table->foreign('language_id')->references('id')->on('languages');
            $table->primary(['i_payment_method_id', 'language_id']);
            $table->string('payment_method', 191);
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('i_payment_method_trans');
    }
}
